package tests;

import java.io.*;

public class Lire {
    public static void main(String[] args){
        try {
            FileReader flot = new FileReader(args[0]);
            BufferedReader flotFiltre = new BufferedReader(flot);
            int nbEntier = 0;
            float moy = 0;
            String ligne = flotFiltre.readLine();
            while (ligne != null) {
                nbEntier++;
                moy += Integer.valueOf(ligne);
                ligne = flotFiltre.readLine();
            }
            flotFiltre.close();
            System.out.println("le nombre d'elements est de: " + nbEntier + " la moyenne est de: " + moy / nbEntier);
        } catch (IOException ex) {
            System.err.println("Le fichier " + args[0] + " n'existe pas");
        }
    }
}
