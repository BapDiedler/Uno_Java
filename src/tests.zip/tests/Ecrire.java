package tests;

import java.io.*;

public class Ecrire {
    public static void main(String[] args) throws IOException {
        if(!new File(args[0]).exists()){
            FileWriter flot = new FileWriter(args[0]);
            BufferedWriter flotFiltre = new BufferedWriter(flot);
            String val;
            for (int i = 1; i <= 1000; i++) {
                val = String.valueOf(i);
                flotFiltre.write(val);
                flotFiltre.newLine();
            }
            flotFiltre.close();
        }else{
            System.err.println("Le fichier "+args[0]+" existe déjà");
        }
    }
}
