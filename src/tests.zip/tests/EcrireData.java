package tests;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class EcrireData {
    public static void main(String[] args) throws IOException {
        FileWriter flot = new FileWriter(args[0]);
        BufferedWriter flotFiltre = new BufferedWriter(flot);
        Random alea = new Random();
        int nbLignes = alea.nextInt(20) + 10;
        int cara = ((alea.nextInt(26)+96));
        cara = (char)cara;
        int entier;
        for(int i=0; i<nbLignes; i++){
            entier = alea.nextInt(13)-5;
            cara = (cara+1);
            if(cara==123){
                cara-=26;
            }
            flotFiltre.write(cara);
            flotFiltre.write(' ');
            flotFiltre.write(String.valueOf(entier));
            flotFiltre.newLine();
        }
        flotFiltre.close();
    }
}
