package tests;

import java.io.*;
import java.util.Random;

public class LireData {
    public static void main(String[] args) throws IOException {
        FileReader flot = new FileReader(args[0]);
        BufferedReader flotFiltre = new BufferedReader(flot);
        char[] tabCara = new char[26];
        float[] tabEntier = new float[26];
        for(int i=0; i<26; i++){
            tabCara[i] = (char)(i+97);
        }
        for(int i=0; i<26; i++){
            tabEntier[i] = 0;
        }
        String ligne = flotFiltre.readLine() ;
        int cpt=0;
        while(ligne != null){
            cpt++;
            if(ligne.charAt(0) <= 122 || ligne.charAt(0) >= 96){
                tabEntier[(int)ligne.charAt(0)-97] += 1.;
            }
            ligne = flotFiltre.readLine();
        }
        for(int i=0; i<26; i++){
            System.out.print(tabCara[i]+" : ");
            System.out.print(tabEntier[i]/cpt);
            System.out.println(" nb : "+ tabEntier[i]);
        }

    }
}
