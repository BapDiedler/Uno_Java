package tests;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EcrireIdentite {

    public static void main(String[] args) throws IOException {
        FileWriter flot = new FileWriter("src/tests/srcTest/essai.txt");
        BufferedWriter flotFiltre = new BufferedWriter(flot) ;
        flotFiltre.write("Diedler");
        flotFiltre.newLine();
        flotFiltre.write("Baptiste");
        flotFiltre.newLine();
        flotFiltre.write("baptiste.diedler@gmail.com");
        flotFiltre.close();
    }
}
