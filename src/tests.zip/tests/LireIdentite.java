package tests;

import java.io.*;

public class LireIdentite {

    public static void main(String[] args) throws IOException {
        FileReader flot = new FileReader("src/tests/srcTest/essai.txt");
        BufferedReader flotFiltre = new BufferedReader(flot);
        int nbLignes = 0;
        String ligne = flotFiltre.readLine() ;
        while (ligne != null) {
            nbLignes++;
            ligne = flotFiltre.readLine() ;
        }
        flotFiltre.close();
        System.out.println(nbLignes);
    }
}
